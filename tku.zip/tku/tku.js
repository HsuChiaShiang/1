const header = document.querySelector('.site-header');
const boxes = document.querySelectorAll('.box');

boxes.forEach(box => {
    var box_widthstyle = window.getComputedStyle(box);
    var box_width = box_widthstyle.width;
    var box_width_value = parseInt(box_width, 10);

    box.addEventListener('click', () => {
        // Get the background image of the clicked box
        const nowHeaderImage =window.getComputedStyle(header).backgroundImage
        const boxBgImage = window.getComputedStyle(box).backgroundImage;
        // Set the header's background image to the clicked box's background image
        header.style.backgroundImage = boxBgImage;
        box.style.backgroundImage = nowHeaderImage;
    });
    box.addEventListener('mouseenter', function(){
        box.style.width = (box_width_value + 300) + 'px';
    })
    box.addEventListener('mouseleave', function(){
            box.style.width = box_width;
    })
});
function displayText(){
    const text = document.getElementById('textField');
    const button = document.getElementById('show-more-button');
    const aside_more = document.getElementsByClassName('aside_more'); // Corrected class name

    if(button.className === "button-show"){
        button.className = '';
        button.style.backgroundColor = "white";
        button.style.color = "black";
        button.textContent = "Show Less";
        text.style.display = 'block';
        for (let i = 0; i < aside_more.length; i++) {
            aside_more[i].style.display = 'block';
        }
    } else {
        button.className = "button-show";
        button.style.backgroundColor = "black";
        button.style.color = "white";
        button.textContent = "Show More";
        text.style.display = 'none';
        for (let i = 0; i < aside_more.length; i++) {
            aside_more[i].style.display = 'none';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('title-list');
    const titles = document.querySelectorAll('main h2');
    
    titles.forEach(title => {
        const li = document.createElement('li');
        li.className = 'aside_more';
        const a = document.createElement('a');
        a.href = `#${title.id}`;
        a.textContent = title.textContent;
        li.appendChild(a);
        sidebar.appendChild(li);
    });
});
