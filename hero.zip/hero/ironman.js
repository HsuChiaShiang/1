document.addEventListener("DOMContentLoaded", function(){
    const pages = document.querySelectorAll('.page');
    const tips = document.getElementById('show-tips');

    const h2 = document.getElementById('h2InIntroduction');
    const img = document.getElementById('imageInIntroduction');
    const p1 = document.getElementById('pInIntroduction'); 
    const p2 = document.getElementById('p1InIntroduction-1'); 
    const h2_1 = document.getElementById('h2InIntroduction-1');
    const iframe_source = document.getElementById('movies');

    let lastTouchedPage = null;
    function showPage(pageId){
        switch(pageId){
            case 'page1':
                window.alert('你正在觀看史塔克工業')
                h2.innerHTML = '史塔克工業'
                p1.innerHTML = `
                    <div style="font-size: 1.1rem; line-height: 1.6; color: #333; margin-bottom: 20px;">
                        <p style="font-weight: bold;">史塔克工業是由鋼鐵人的父親創辦，而鋼鐵人對於機械和電子有極大的興趣。在接手創辦人的企業之後，鋼鐵人對於機械和武器有更多不一樣的研發，其中發明了戰爭晶片，也吸引了各大軍火商和政府的關注。然而，在一次交易中，鋼鐵人遭受到買家的欺騙和俘虜。在俘虜過程中，心臟受到子彈碎片的侵入，為了延續生命，他不斷研發更多機械，其中反應堆核心成為他續命的方式。反應堆在初步設計時帶有輻射線，對於他的身體造成極大的傷害。然而，他並沒有因此停下腳步，而是繼續改良反應堆，使其更為安全和高效。這個反應堆不僅是他生存的關鍵，也成為鋼鐵人裝甲的核心動力來源。鋼鐵人裝甲是一項革命性的戰爭武器，能夠大幅提升使用者的能力。這套裝甲不僅擁有強大的防禦力和攻擊力，還配備了多種先進科技，例如飛行能力、高精度武器系統和強大的人工智能助手。托尼·史塔克利用這套裝甲，不僅拯救了自己的生命，也成為了世界的守護者。隨著時間的推移，托尼不斷改進和升級他的裝甲，應對越來越強大的敵人和挑戰。每一次升級都代表著科技的進步和托尼對於保護世界的承諾。他的鋼鐵人裝甲也成為了許多英雄和反派爭相模仿的對象，史塔克工業因此在全球範圍內產生了深遠的影響。托尼·史塔克不僅是一位天才發明家，更是一位勇敢無畏的英雄。他的故事告訴我們，即使面對再大的困難和挑戰，只要勇於創新和堅持，就能夠改變世界。鋼鐵人的傳奇，將永遠激勵著無數後來者，去探索未知，挑戰極限，為人類的未來開創無限可能。</p>
                    </div>
                `;
                tips.style.display = 'none';//
                img.src = '/image_tku/sellweapon.jpeg';
                p2.innerHTML = "史塔克工業在漫威電影中扮演重要的角色，不論是在復仇者聯盟中討論和集合的聚集地，也是許多超級英雄裝備的製造商，更是因為科技太過於領先，經常被社會大眾和政府認為是邪惡的存在。";
                h2_1.style.display = 'block';
                break;
            case 'page2':
                window.alert('你正在觀看鋼鐵人戰衣')
                h2.innerHTML = '鋼鐵人戰衣';
                p1.innerHTML = '鋼鐵人的裝甲主要由鈦金屬等其他金屬的合金為主要成分，形成一個高機動性及極度堅實且能提供極高防禦作用的外殼。 裝甲能賦予東尼超人的力量及飛行能力，其能源來自東尼的胸口的電弧反應爐，但也可以吸收周遭的能源如熱量與動能並轉化成電力，甚至可以直接吸收電力來為電池進行充電。';
                tips.style.display = 'none';//
                img.src = '/image_tku/ironmen.jpeg';
                p2.innerHTML = `
                    <p>共有52個戰衣，下方四個是最著名的戰衣：</p>
                    <ul>
                        <li>一型 Mark：第一代鋼鐵人戰衣，東尼被「十環幫」囚禁時與何銀森利用周遭的簡陋工具所製造的裝甲。武器包括兩具火焰發射器、一支火箭和一具噴射背包，但防禦力較差。</li>
                        <li>四型 Mark IV：盔甲的包覆程度提升，強化攻擊、防禦和生存功能，甚至能將尿液過濾成飲用水。</li>
                        <li>三十三型 Mark XXXIII 銀色百夫長 Silver Centurion：能夠利用磁場極性來吸引或排斥對象，並能發射脈衝炮。</li>
                        <li>八十五型 Mark LXXXV：於《復仇者聯盟4：終局之戰》中登場，是東尼製造的最後一套裝甲，為改良版的五十型裝甲。這套裝甲是東尼最強的一套，可單獨穿戴部件，外觀更鋒利，配色回歸初代鋼鐵人漫畫的風格。背部配有六聯裝重型集束炮，並可直接使用外部能源（如雷神索爾的閃電力）來增強火力。</li>
                    </ul>
                `;

                h2_1.style.display = 'block';
                break;
            case 'page3':
                window.alert('你正觀看相關資訊');
                h2.innerHTML = '電影介紹電影';
                p1.innerHTML = '這一部電影是對於鋼鐵人來說巨大貢獻，也因為有這一部電影，讓鋼鐵人有不一樣的面向，其中因為東尼因紐約事件而患上了失眠及焦慮症，於是寄情於製造大量不同型號的裝甲和戰甲。';
                iframe_source.style.display = 'block';
                iframe_source.src = 'https://www.youtube.com/embed/LSMSmBBHnp0';
                tips.style.display = 'none'
                h2_1.style.display = 'block';
                p2.innerHTML = "鋼鐵人1、鋼鐵人2、鋼鐵人3";
                break;
        }
    };
    pages.forEach(page => {
        page.addEventListener('click', function(){
            if(lastTouchedPage != null){
                lastTouchedPage.style.backgroundColor = '';
            }
            this.style.backgroundColor = 'rgba(240, 248, 255, 0.835)';
            lastTouchedPage = this;
            const pageId = this.id;
            showPage(pageId);
        })
    })
})
var button = document.querySelectorAll('.button1');
function goBack(event){
    window.confirm("ARE YOU SURE?");
    if(confirm("ARE YOU SURE?") == true){
        window.location.href = "/tku/tku.html";
    }
}
const tipsAside = document.getElementById('tips');
const tipsbox = document.getElementById('show-name');
function tipsButton(){
    tipsbox.style.backgroundColor = 'rgba(240, 248, 255, 0.5)';
    tipsAside.innerHTML = 'You can press the button at any time to go back.';
}  
function tipsButton_0(){
    tipsbox.style.backgroundColor = 'rgba(240, 248, 255, 0)';
    tipsAside.innerHTML = '';
    
}  
button.forEach(function(button) {
    button.addEventListener('click', goBack);
});



