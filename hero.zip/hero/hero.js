document.addEventListener("DOMContentLoaded", function(){
    const pages = document.querySelectorAll('.page');
    const tips = document.getElementById('show-tips');

    const h2 = document.getElementById('h2InIntroduction');
    const img = document.getElementById('imageInIntroduction');
    const p1 = document.getElementById('pInIntroduction'); 
    const p2 = document.getElementById('p1InIntroduction-1'); 
    const h2_1 = document.getElementById('h2InIntroduction-1');
    const iframe_source = document.getElementById('movies');

    let lastTouchedPage = null;
    function showPage(pageId){
        switch(pageId){
            case 'page1':
                window.alert('你正在觀看第一代蜘蛛人');
                iframe_source.style.display = 'block';
                iframe_source.src = 'https://www.youtube.com/embed/2xOEtS8Y8pE';
                p1.innerHTML = "在一次校外郊遊參觀哥倫比亞大學的基因實驗室時，意外被一隻逃出實驗槽的基因重組「超級蜘蛛」在手上咬下一口，彼得當時並沒有理會，然而回家後感到渾身不舒服而倒地昏迷一晚上。與此同時，彼得的摯友哈利·奧斯本之父諾曼身為奧氏企業的執行長兼科學家，由於近年來始終沒有在人體增強實驗中取得重大成果，為了保住自己一手創辦的公司與美國軍方簽訂的合約，決定冒險親自當人體實驗對象。當諾曼測試並吸入一種新發明且性質不明的血清後，在大幅增強他的速度、力量和耐力的同時，卻也令他精神分裂，當場發狂並殺死一旁的助手。隔天清醒的彼得發現自己在一夜之間變得身強體壯、不再近視，速度、敏銳度等各項能力都得到大幅度提升";
                tips.style.display = 'none';
                img.src = '/image_tku/spm1.webp';
                h2.innerHTML = "第一代蜘蛛人";
                p2.innerHTML = "蜘蛛人1、蜘蛛人2、蜘蛛人3";
                h2_1.style.display = 'block';
                break;
            case 'page2':
                window.alert('你正在觀看第二代蜘蛛人');
                iframe_source.style.display = 'block';
                iframe_source.src ="https://www.youtube.com/embed/m9a927XJ24s"
                p1.innerHTML = "第二代蜘蛛人比第一代更加忠實於漫畫，雖然從小歷經父母雙亡、至親班叔因他死亡，以及摯愛關史黛西離世，種種悲傷及痛苦加成，但無損於他帥氣美少年氣息，也成就他長成強大的蜘蛛人。發明了「蜘蛛絲發射器」，並且自製戰衣。而且跟第一代蜘蛛人一樣，二隻的防禦力幾乎為零，全靠矯健的身手續命。";
                img.src = '/image_tku/spm2.jpeg';
                h2.innerHTML = "第二代蜘蛛人";
                tips.style.display = 'none';
                h2_1.style.display = 'block';
                p2.innerHTML = "蜘蛛人:驚奇再起1、蜘蛛人:驚奇再起2";
                break;
            case 'page3':
                window.alert('你正在觀看第三代蜘蛛人');
                iframe_source.style.display = 'block';
                iframe_source.src="https://www.youtube.com/embed/bPXI4sGdVxQ"
                p1.innerHTML = "彼得·班傑明·帕克，是漫威電影宇宙（Marvel Cinematic Universe）中的一名虛構人物，當前（截至2022年）由湯姆·霍蘭德飾演，在其他由索尼所擁有的蜘蛛人系列電影中曾經由陶比·麥奎爾和安德魯·加菲爾德飾演。該角色源自於漫威漫畫的同名超級英雄蜘蛛人（Spider Man）。在漫威電影宇宙中，彼得·帕克是一名在紐約市就讀中城科技高中的學生。在遭到一隻輻射污染的蜘蛛咬傷後獲得蜘蛛的超能力。彼得用超能力打擊犯罪並成為匿名英雄蜘蛛人。之後「鋼鐵人」東尼·史塔克招募彼得成為復仇者聯盟成員[1]，並肩對抗薩諾斯等反派。從彈指事件復活後，因為被神秘法師惡意公布其身份而尋求奇異博士的幫忙，卻意外造成一場多重宇宙危機。為了解決危機，彼得請求奇異博士把彼得·帕克是蜘蛛人的身份從世人的記憶抹除，卻因意外導致魔法失控、多重宇宙入侵，為此他得四處抓捕來自不同宇宙的反派，與另外兩位同樣穿越過來的蜘蛛人並肩作戰。在成為無名氏後，彼得重拾蜘蛛人的身份，開始新的生活。";
                img.src = '/image_tku/spm3.png';
                h2.innerHTML = "第三代蜘蛛人";
                tips.style.display = 'none';
                h2_1.style.display = 'block';
                p2.innerHTML = "蜘蛛人:返校日、蜘蛛人:無家日、";
                break;
        }
    };
    pages.forEach(page => {
        page.addEventListener('click', function(){
            if(lastTouchedPage != null){
                lastTouchedPage.style.backgroundColor = '';
            }
            this.style.backgroundColor = 'rgba(240, 248, 255, 0.835)';
            lastTouchedPage = this;
            const pageId = this.id;
            showPage(pageId);
        })
    })
})

var button = document.querySelectorAll('.button1');
function goBack(event){
    window.confirm("ARE YOU SURE?");
    if(confirm("ARE YOU SURE?") == true){
        window.location.href = "/tku/tku.html";
    }
}
const tipsAside = document.getElementById('tips');
const tipsbox = document.getElementById('show-name');
function tipsButton(){
    tipsbox.style.backgroundColor = 'rgba(240, 248, 255, 0.5)';
    tipsAside.innerHTML = 'You can press the button at any time to go back.';
}  
function tipsButton_0(){
    tipsbox.style.backgroundColor = 'rgba(240, 248, 255, 0)';
    tipsAside.innerHTML = '';
    
}  
button.forEach(function(button) {
    button.addEventListener('click', goBack);
});
