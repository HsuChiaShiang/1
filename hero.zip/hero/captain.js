document.addEventListener("DOMContentLoaded", function(){
    const pages = document.querySelectorAll('.page');
    const tips = document.getElementById('show-tips');

    const h2 = document.getElementById('h2InIntroduction');
    const img = document.getElementById('imageInIntroduction');
    const p1 = document.getElementById('pInIntroduction'); 
    const p2 = document.getElementById('p1InIntroduction-1'); 
    const h2_1 = document.getElementById('h2InIntroduction-1');
    const iframe_source = document.getElementById('movies');

    let lastTouchedPage = null;
    function showPage(pageId){
        switch(pageId){
            case 'page1':
                window.alert('你正在觀看美國隊長的介紹');
                iframe_source.style.display = 'none';
                iframe_source.src = 'https://www.youtube.com/embed/2xOEtS8Y8pE';
                p1.innerHTML = "美國隊長出生在1920年代，他是出生環境是在二次世界大戰中，因為面臨二次世界大戰，對於美國隊長來說參軍是他對於愛國的表現，因為他身體素質偏瘦弱，因此無法參軍，但是剛好被上笑看到，因此詢問是否參加身體改造計畫，血清成功地將史蒂夫變成了一個近乎完美的人類，具有超人的力量、敏捷度、耐力和智力。該計劃的成功讓厄斯金想將這個實驗複製到其他人身上。但是因為朋友被殺害加上計劃失敗，導致美國隊長的精神錯亂迫使美國政府將他們置於無限期的低溫儲存中，直到他們能夠治癒他們的精神疾病。";
                tips.style.display = 'none';
                img.src = '/image_tku/captain1.jpeg';
                h2.innerHTML = "美國隊長介紹";
                p2.innerHTML = "美國隊長一共有三個盾牌，最常使用的是一個畫有星形的圓形盾牌。這個盾牌是由一種被稱為「汎金屬」的罕有金屬的合金所製成，馬龍·麥特連恩博士因為一場意外而製造出了以汎金屬為主原料的合金，然而因為其製造過程屬於意外，所以其原料比例和合金的過程完全不明，它有著吸收能量的功能，而且是漫威宇宙中最堅硬的材質之一";
                h2_1.style.display = 'block';
                break;
            case 'page2':
                window.alert('你正在觀看美國隊長相關資訊');
                iframe_source.style.display = 'block';
                iframe_source.src ="https://www.youtube.com/embed/qTwO8Ni4FFY"
                p1.innerHTML = "";
                img.src = '/image_tku/captain2.jpeg';
                h2.innerHTML = "相關資訊";
                tips.style.display = 'none';
                h2_1.style.display = 'block';
                p2.innerHTML = "《美國隊長》（2011年）《復仇者聯盟》《美國隊長2：酷寒戰士》《復仇者聯盟2：奧創紀元》《美國隊長3：英雄內戰》《復仇者聯盟：無限之戰》《復仇者聯盟：終局之戰》";
                break;
        }
    };
    pages.forEach(page => {
        page.addEventListener('click', function(){
            if(lastTouchedPage != null){
                lastTouchedPage.style.backgroundColor = '';
            }
            this.style.backgroundColor = 'rgba(240, 248, 255, 0.835)';
            lastTouchedPage = this;
            const pageId = this.id;
            showPage(pageId);
        })
    })
})

var button = document.querySelectorAll('.button1');
function goBack(event){
    window.confirm("ARE YOU SURE?");
    if(confirm("ARE YOU SURE?") == true){
        window.location.href = "/tku/tku.html";
    }
}
const tipsAside = document.getElementById('tips');
const tipsbox = document.getElementById('show-name');
function tipsButton(){
    tipsbox.style.backgroundColor = 'rgba(240, 248, 255, 0.5)';
    tipsAside.innerHTML = 'You can press the button at any time to go back.';
}  
function tipsButton_0(){
    tipsbox.style.backgroundColor = 'rgba(240, 248, 255, 0)';
    tipsAside.innerHTML = '';
    
}  
button.forEach(function(button) {
    button.addEventListener('click', goBack);
});
